from datetime import date
today=date.today()
import sqlite3
conn=sqlite3.connect('record.db')
conn.execute('''CREATE TABLE IF NOT EXISTS BILL(DATE NOT NULL,BILL_NO INT,AMOUNT INT)''')
##conn.execute("INSERT INTO BILL (DATE,BILL_NO,AMOUNT) VALUES(?,?,?)",('0000-00-00',0,0))
cursor=conn.execute("SELECT * FROM BILL")
for i in (cursor.fetchall()):
    print(i)


conn.commit()
conn.close()
